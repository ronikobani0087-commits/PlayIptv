package com.myiptv.app.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** A custom order (JSON array of keys) for a list, chosen by the user with drag and drop. */
@Entity(tableName = "order_prefs",
        indices = {@Index(value = {"playlistId", "scope"}, unique = true)})
public class OrderPref {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long playlistId;
    public String scope;
    public String json;
}
