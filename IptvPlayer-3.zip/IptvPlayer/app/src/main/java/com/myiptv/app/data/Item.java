package com.myiptv.app.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "items",
        indices = {
                @Index(value = {"playlistId", "type", "categoryRemoteId", "position"}),
                @Index(value = {"playlistId", "type", "position"})
        })
public class Item {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long playlistId;
    /** "live", "movie" or "series" */
    public String type;
    public String categoryRemoteId;
    public String remoteId;
    public String name;
    public String icon;
    public String streamUrl;
    public String rating;
    public String year;
    /** Order as returned by the provider. */
    public int position;
    /** Unix seconds when the provider added/modified it (0 if unknown). */
    public long added;
}
