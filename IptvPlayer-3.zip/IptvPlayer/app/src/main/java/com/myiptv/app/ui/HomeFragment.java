package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.EpgRepository;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private TextView subtitle;
    private TextView counts;
    private TextView status;
    private TextView action;
    private TextView refresh;
    private CardStrip stripMatches;
    private CardStrip stripFav;
    private CardStrip stripFollow;
    private CardStrip stripRecent;
    private long activeId = -1;
    private int loadToken;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(c);
        title.setText("الرئيسية");
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(24);
        title.setTypeface(title.getTypeface(), Typeface.BOLD);
        root.addView(title);

        subtitle = new TextView(c);
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(14);
        subtitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        root.addView(subtitle, lp(c, 6));

        counts = new TextView(c);
        counts.setTextColor(ContextCompat.getColor(c, R.color.accent));
        counts.setTextSize(14);
        root.addView(counts, lp(c, 4));

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(14);
        status.setLineSpacing(0, 1.3f);
        root.addView(status, lp(c, 8));

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        action = Ui.button(c, "إضافة قائمة", true);
        row.addView(action);
        refresh = Ui.button(c, "تحديث القائمة", false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.setMarginStart(Ui.dp(c, 10));
        refresh.setOnClickListener(v -> doRefresh());
        refresh.setVisibility(View.GONE);
        row.addView(refresh, fp);
        root.addView(row, lp(c, 12));

        stripMatches = new CardStrip(c, "أهم المباريات", null);
        stripFav = new CardStrip(c, "المفضلة",
                "اضغط على النجمة ☆ بجانب أي قناة أو فيلم أو مسلسل ليظهر هنا.");
        stripFollow = new CardStrip(c, "مسلسلات أتابعها", null);
        stripRecent = new CardStrip(c, "أهم المسلسلات المضافة مؤخراً", null);
        root.addView(stripMatches.view, lp(c, 24));
        root.addView(stripFav.view, lp(c, 24));
        root.addView(stripFollow.view, lp(c, 24));
        root.addView(stripRecent.view, lp(c, 24));
        return scroll;
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(c, topDp);
        return p;
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        final int token = ++loadToken;
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            UserDao ud = UserDatabase.get(app).dao();
            long id = Prefs.getActive(app);
            final Playlist p = id < 0 ? null : db.dao().getPlaylist(id);

            int live = 0, movies = 0, series = 0;
            List<Favorite> favs = new ArrayList<>();
            List<History> follow = new ArrayList<>();
            List<Item> recent = new ArrayList<>();
            List<Item> bein = new ArrayList<>();
            if (p != null) {
                live = db.dao().countItems(p.id, "live");
                movies = db.dao().countItems(p.id, "movie");
                series = db.dao().countItems(p.id, "series");
                favs = ud.favorites(p.id, 40);
                follow = ud.recentHistory(p.id, "series", 20);
                recent = db.dao().recentSeries(p.id, 20);
                bein = db.dao().beinChannels(p.id, 24);
            }
            final int fLive = live, fMovies = movies, fSeries = series;
            final List<Favorite> fFavs = favs;
            final List<History> fFollow = follow;
            final List<Item> fRecent = recent;
            final List<Item> fBein = bein;

            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                bind(p, fLive, fMovies, fSeries, fFavs, fFollow, fRecent);
            });

            if (p != null && !fBein.isEmpty()) {
                loadMatches(p, fBein, token);
            } else {
                Async.main(() -> {
                    if (isAdded() && token == loadToken) stripMatches.set(new ArrayList<CardStrip.Card>());
                });
            }
        });
    }

    private void bind(@Nullable Playlist p, int live, int movies, int series,
                      List<Favorite> favs, List<History> follow, List<Item> recent) {
        NumberFormat nf = NumberFormat.getInstance();
        final long pid = p == null ? -1 : p.id;
        activeId = pid;
        if (p == null) {
            subtitle.setText("");
            counts.setText("");
            status.setText("لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.");
        } else {
            String when = p.updatedAt > 0
                    ? "  ·  آخر تحديث: " + DateFormat.getDateTimeInstance(
                    DateFormat.SHORT, DateFormat.SHORT).format(new Date(p.updatedAt))
                    : "";
            subtitle.setText(p.name + when);
            counts.setText(nf.format(live) + " قناة  ·  " + nf.format(movies) + " فيلم  ·  "
                    + nf.format(series) + " مسلسل");
            if (status.getText().length() > 0 && !status.getText().toString().startsWith("تعذر")) {
                status.setText("");
            }
        }
        refresh.setVisibility(pid < 0 ? View.GONE : View.VISIBLE);
        action.setText(pid < 0 ? "إضافة قائمة" : "إدارة القوائم");
        action.setOnClickListener(v -> {
            MainActivity a = (MainActivity) requireActivity();
            if (activeId < 0) a.openAddPlaylist();
            else a.select(R.id.nav_settings);
        });

        // Favorites
        List<CardStrip.Card> favCards = new ArrayList<>();
        for (final Favorite f : favs) {
            CardStrip.Card c = new CardStrip.Card();
            c.title = nz(f.name);
            c.subtitle = typeLabel(f.type);
            c.image = nz(f.icon);
            c.fallback = iconFor(f.type);
            c.click = () -> openFavorite(f);
            favCards.add(c);
        }
        stripFav.set(pid < 0 ? new ArrayList<CardStrip.Card>() : favCards);

        // Series I follow
        List<CardStrip.Card> followCards = new ArrayList<>();
        for (final History h : follow) {
            CardStrip.Card c = new CardStrip.Card();
            c.title = nz(h.name);
            c.subtitle = nz(h.episodeTitle);
            c.image = nz(h.icon);
            c.fallback = R.drawable.ic_series;
            c.click = () -> resume(h);
            followCards.add(c);
        }
        stripFollow.set(followCards);

        // Recently added series
        List<CardStrip.Card> recentCards = new ArrayList<>();
        for (final Item it : recent) {
            CardStrip.Card c = new CardStrip.Card();
            c.title = nz(it.name);
            c.subtitle = nz(it.year);
            c.image = nz(it.icon);
            c.fallback = R.drawable.ic_series;
            c.click = () -> {
                if (!isAdded()) return;
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    PlayerActivity.start(requireContext(), it.streamUrl, it.name);
                } else {
                    SeriesPicker.show(requireActivity(), activeId, it.name, it.remoteId, it.icon);
                }
            };
            recentCards.add(c);
        }
        stripRecent.set(recentCards);
    }

    private void loadMatches(final Playlist p, final List<Item> bein, final int token) {
        new Thread(() -> {
            List<EpgRepository.Match> matches = new ArrayList<>();
            if ("xtream".equals(p.type)) {
                try {
                    matches = EpgRepository.load(p, bein);
                } catch (Exception ignored) {
                    // fall back to the channel list below
                }
            }
            final List<CardStrip.Card> cards = new ArrayList<>();
            final boolean fallback = matches.isEmpty();
            long now = System.currentTimeMillis() / 1000L;
            if (!fallback) {
                for (final EpgRepository.Match m : matches) {
                    CardStrip.Card c = new CardStrip.Card();
                    c.wide = true;
                    c.title = m.title;
                    c.subtitle = timeLabel(m.start) + " · " + m.channel;
                    c.badge = (m.start <= now && now < m.stop) ? "● الآن" : "";
                    c.click = () -> play(m.streamUrl, m.title);
                    cards.add(c);
                }
            } else {
                for (final Item it : bein) {
                    CardStrip.Card c = new CardStrip.Card();
                    c.title = nz(it.name);
                    c.subtitle = "بث مباشر";
                    c.image = nz(it.icon);
                    c.fallback = R.drawable.ic_live;
                    c.click = () -> play(it.streamUrl, it.name);
                    cards.add(c);
                }
            }
            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                stripMatches.setTitle(fallback ? "أهم المباريات · قنوات بي إن سبورت" : "أهم المباريات");
                stripMatches.set(cards);
            });
        }).start();
    }

    private void play(String url, String title) {
        if (!isAdded() || url == null || url.isEmpty()) return;
        PlayerActivity.start(requireContext(), url, title);
    }

    private void openFavorite(Favorite f) {
        if (!isAdded()) return;
        if ("series".equals(f.type) && (f.streamUrl == null || f.streamUrl.isEmpty())) {
            SeriesPicker.show(requireActivity(), activeId, f.name, f.remoteId, f.icon);
        } else {
            play(f.streamUrl, f.name);
        }
    }

    private void resume(History h) {
        if (!isAdded()) return;
        if (h.streamUrl == null || h.streamUrl.isEmpty()) {
            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
            return;
        }
        PlayerActivity.startTracked(requireContext(), h.streamUrl, h.name + " - " + nz(h.episodeTitle),
                h.playlistId, "series", h.remoteId, h.name, h.icon, h.episodeTitle, h.positionMs);
    }

    private static String timeLabel(long startSec) {
        Calendar now = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        start.setTimeInMillis(startSec * 1000L);
        String hm = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(start.getTime());
        if (start.getTimeInMillis() <= System.currentTimeMillis()) return "بدأت " + hm;
        int dayDiff = start.get(Calendar.DAY_OF_YEAR) - now.get(Calendar.DAY_OF_YEAR);
        if (start.get(Calendar.YEAR) != now.get(Calendar.YEAR)) dayDiff = 2;
        if (dayDiff == 0) return "اليوم " + hm;
        if (dayDiff == 1) return "غداً " + hm;
        return new SimpleDateFormat("d/M HH:mm", Locale.getDefault()).format(start.getTime());
    }

    private static String typeLabel(String type) {
        if ("movie".equals(type)) return "فيلم";
        if ("series".equals(type)) return "مسلسل";
        return "قناة مباشرة";
    }

    private static int iconFor(String type) {
        if ("movie".equals(type)) return R.drawable.ic_movie;
        if ("series".equals(type)) return R.drawable.ic_series;
        return R.drawable.ic_live;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private void doRefresh() {
        if (activeId < 0) return;
        refresh.setEnabled(false);
        SyncRepository.sync(requireContext(), activeId, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                status.setText("");
                load();
            }

            @Override
            public void onError(String message) {
                if (!isAdded()) return;
                refresh.setEnabled(true);
                status.setText("تعذر التحديث: " + message);
            }
        });
    }
}
