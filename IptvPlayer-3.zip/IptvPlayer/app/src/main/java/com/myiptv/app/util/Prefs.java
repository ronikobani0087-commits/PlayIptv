package com.myiptv.app.util;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("app", Context.MODE_PRIVATE);
    }

    public static long getActive(Context c) {
        return sp(c).getLong("active_playlist", -1L);
    }

    public static void setActive(Context c, long id) {
        sp(c).edit().putLong("active_playlist", id).apply();
    }
}
