package com.myiptv.app.util;

import android.content.Context;
import android.view.Gravity;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static TextView button(Context c, String text, boolean primary) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(ContextCompat.getColor(c, primary ? R.color.on_accent : R.color.text));
        b.setBackgroundResource(primary ? R.drawable.bg_button : R.drawable.bg_button_secondary);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 18), dp(c, 11), dp(c, 18), dp(c, 11));
        return b;
    }
}
