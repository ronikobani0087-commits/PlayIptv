package com.myiptv.app.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/** Separate database for things the user creates (favorites, history, custom order). */
@Database(entities = {Favorite.class, History.class, OrderPref.class}, version = 1, exportSchema = false)
public abstract class UserDatabase extends RoomDatabase {
    public abstract UserDao dao();

    private static volatile UserDatabase instance;

    public static UserDatabase get(Context context) {
        if (instance == null) {
            synchronized (UserDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                            UserDatabase.class, "user.db").build();
                }
            }
        }
        return instance;
    }
}
