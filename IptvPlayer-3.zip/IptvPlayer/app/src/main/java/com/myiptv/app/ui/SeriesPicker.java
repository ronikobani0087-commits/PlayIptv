package com.myiptv.app.ui;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Http;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/** Loads the episodes of an Xtream series and lets the user pick one to play. */
public final class SeriesPicker {
    private SeriesPicker() {}

    public static void show(final Activity activity, final long playlistId, final String seriesName,
                            final String seriesId, final String icon) {
        final Context app = activity.getApplicationContext();
        Toast.makeText(app, "جارٍ تحميل الحلقات…", Toast.LENGTH_SHORT).show();
        Async.io(() -> {
            try {
                Playlist p = AppDatabase.get(app).dao().getPlaylist(playlistId);
                if (p == null || !"xtream".equals(p.type)) {
                    throw new Exception("الحلقات غير متاحة لهذه القائمة");
                }
                String uenc = URLEncoder.encode(p.username, "UTF-8");
                String penc = URLEncoder.encode(p.password, "UTF-8");
                String api = p.url + "/player_api.php?username=" + uenc + "&password=" + penc
                        + "&action=get_series_info&series_id=" + URLEncoder.encode(seriesId, "UTF-8");
                JSONObject o = new JSONObject(Http.readString(api));
                JSONObject eps = o.optJSONObject("episodes");

                final List<String> titles = new ArrayList<>();
                final List<String> shortTitles = new ArrayList<>();
                final List<String> urls = new ArrayList<>();
                if (eps != null) {
                    List<String> seasons = new ArrayList<>();
                    Iterator<String> keys = eps.keys();
                    while (keys.hasNext()) seasons.add(keys.next());
                    Collections.sort(seasons, new Comparator<String>() {
                        @Override
                        public int compare(String a, String b) {
                            return Integer.compare(toInt(a), toInt(b));
                        }
                    });
                    for (String season : seasons) {
                        JSONArray arr = eps.optJSONArray(season);
                        if (arr == null) continue;
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject ep = arr.optJSONObject(i);
                            if (ep == null) continue;
                            String id = ep.optString("id", "");
                            if (id.isEmpty()) continue;
                            String ext = ep.optString("container_extension", "mp4");
                            if (ext.isEmpty()) ext = "mp4";
                            String num = ep.optString("episode_num", String.valueOf(i + 1));
                            String t = ep.optString("title", "");
                            String shortTitle = "الموسم " + season + " · الحلقة " + num;
                            shortTitles.add(shortTitle);
                            titles.add(shortTitle + (t.isEmpty() ? "" : " · " + t));
                            urls.add(p.url + "/series/" + uenc + "/" + penc + "/" + id + "." + ext);
                        }
                    }
                }

                History h = UserDatabase.get(app).dao().getHistory(playlistId, "series", seriesId);
                final String lastUrl = h == null || h.streamUrl == null ? "" : h.streamUrl;
                final long lastPos = h == null ? 0L : h.positionMs;

                Async.main(() -> {
                    if (activity.isFinishing() || activity.isDestroyed()) return;
                    if (titles.isEmpty()) {
                        Toast.makeText(activity, "لا توجد حلقات لهذا المسلسل", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String[] labels = new String[titles.size()];
                    for (int i = 0; i < labels.length; i++) {
                        labels[i] = (urls.get(i).equals(lastUrl) ? "▶ " : "") + titles.get(i);
                    }
                    new AlertDialog.Builder(activity)
                            .setTitle(seriesName)
                            .setItems(labels, (d, which) -> {
                                String url = urls.get(which);
                                long pos = url.equals(lastUrl) ? lastPos : 0L;
                                PlayerActivity.startTracked(activity, url,
                                        seriesName + " - " + titles.get(which), playlistId, "series",
                                        seriesId, seriesName, icon, shortTitles.get(which), pos);
                            })
                            .show();
                });
            } catch (Exception ex) {
                final String m = ex.getMessage() == null ? "تعذر تحميل الحلقات" : ex.getMessage();
                Async.main(() -> {
                    if (!activity.isFinishing()) Toast.makeText(activity, m, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
