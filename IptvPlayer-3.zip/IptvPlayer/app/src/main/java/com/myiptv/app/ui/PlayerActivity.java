package com.myiptv.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.myiptv.app.data.History;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Players;
import com.myiptv.app.util.Ui;

/** Full screen video player. */
public class PlayerActivity extends AppCompatActivity {
    private static final String EXTRA_URL = "url";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_PLAYLIST = "playlist";
    private static final String EXTRA_TYPE = "type";
    private static final String EXTRA_REMOTE = "remote";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ICON = "icon";
    private static final String EXTRA_EPISODE = "episode";
    private static final String EXTRA_POS = "pos";

    public static void start(Context context, String url, String title) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        context.startActivity(i);
    }

    /** Plays a series episode and remembers where the user stopped (for "series I follow"). */
    public static void startTracked(Context context, String url, String title, long playlistId,
                                    String type, String remoteId, String name, String icon,
                                    String episode, long positionMs) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_PLAYLIST, playlistId);
        i.putExtra(EXTRA_TYPE, type);
        i.putExtra(EXTRA_REMOTE, remoteId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ICON, icon);
        i.putExtra(EXTRA_EPISODE, episode);
        i.putExtra(EXTRA_POS, positionMs);
        context.startActivity(i);
    }

    private long trackPlaylist = -1;
    private String trackType, trackRemote, trackName, trackIcon, trackEpisode;
    private long startPos;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PlayerView playerView;
    private TextView message;
    private TextView titleView;
    private ExoPlayer player;
    private String url;

    private final Runnable hideTitle = new Runnable() {
        @Override
        public void run() {
            titleView.setVisibility(View.GONE);
        }
    };

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_BUFFERING) {
                message.setText("جارٍ التحميل…");
                message.setVisibility(View.VISIBLE);
            } else if (state == Player.STATE_READY) {
                message.setVisibility(View.GONE);
            }
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            message.setText("تعذر تشغيل هذا المحتوى (" + error.getErrorCodeName() + ")");
            message.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getIntent().getStringExtra(EXTRA_URL);
        String name = getIntent().getStringExtra(EXTRA_TITLE);
        trackPlaylist = getIntent().getLongExtra(EXTRA_PLAYLIST, -1L);
        trackType = getIntent().getStringExtra(EXTRA_TYPE);
        trackRemote = getIntent().getStringExtra(EXTRA_REMOTE);
        trackName = getIntent().getStringExtra(EXTRA_NAME);
        trackIcon = getIntent().getStringExtra(EXTRA_ICON);
        trackEpisode = getIntent().getStringExtra(EXTRA_EPISODE);
        startPos = getIntent().getLongExtra(EXTRA_POS, 0L);
        if (url == null || url.isEmpty()) {
            finish();
            return;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        playerView = new PlayerView(this);
        playerView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        playerView.setKeepScreenOn(true);
        playerView.setUseController(true);
        playerView.setFocusable(true);
        root.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        message = new TextView(this);
        message.setTextColor(0xFFFFFFFF);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        root.addView(message, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        titleView = new TextView(this);
        titleView.setText(name == null ? "" : name);
        titleView.setTextColor(0xFFFFFFFF);
        titleView.setTextSize(16);
        titleView.setBackgroundColor(0x88000000);
        titleView.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        root.addView(titleView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        setContentView(root);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);

        handler.postDelayed(hideTitle, 4000);
        playerView.requestFocus();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (url == null || url.isEmpty()) return;
        player = Players.create(this);
        player.addListener(listener);
        playerView.setPlayer(player);
        message.setText("جارٍ التحميل…");
        message.setVisibility(View.VISIBLE);
        player.setMediaItem(MediaItem.fromUri(url));
        if (startPos > 0) player.seekTo(startPos);
        player.prepare();
        player.play();
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveHistory();
        releasePlayer();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(hideTitle);
        super.onDestroy();
    }

    private void saveHistory() {
        if (player == null || trackPlaylist < 0 || trackType == null || trackRemote == null) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        if (pos < 5000) return;
        if (dur > 0 && pos > dur * 95 / 100) pos = 0;
        startPos = pos;
        final History h = new History();
        h.playlistId = trackPlaylist;
        h.type = trackType;
        h.remoteId = trackRemote;
        h.name = trackName == null ? "" : trackName;
        h.icon = trackIcon == null ? "" : trackIcon;
        h.episodeTitle = trackEpisode == null ? "" : trackEpisode;
        h.streamUrl = url;
        h.positionMs = pos;
        h.updatedAt = System.currentTimeMillis();
        final Context app = getApplicationContext();
        Async.io(() -> UserDatabase.get(app).dao().putHistory(h));
    }

    private void releasePlayer() {
        if (player != null) {
            player.removeListener(listener);
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }
}
