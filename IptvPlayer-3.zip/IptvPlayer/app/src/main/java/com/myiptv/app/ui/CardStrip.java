package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Ui;

import java.util.ArrayList;
import java.util.List;

/** A titled horizontal row of cards, used on the home screen. */
public final class CardStrip {
    public static final class Card {
        public String title = "";
        public String subtitle = "";
        public String badge = "";
        public String image = "";
        public int fallback = R.drawable.ic_movie;
        /** Text-only wide card (used for matches). */
        public boolean wide;
        public Runnable click;
    }

    public final LinearLayout view;
    private final TextView heading;
    private final TextView hint;
    private final RecyclerView list;
    private final String emptyHint;
    private final Adapter adapter = new Adapter();

    /** @param emptyHint shown under the title when there are no cards; null hides the whole strip. */
    public CardStrip(Context c, String title, String emptyHint) {
        this.emptyHint = emptyHint;
        view = new LinearLayout(c);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setVisibility(View.GONE);

        heading = new TextView(c);
        heading.setText(title);
        heading.setTextColor(ContextCompat.getColor(c, R.color.text));
        heading.setTextSize(17);
        heading.setTypeface(heading.getTypeface(), Typeface.BOLD);
        view.addView(heading);

        hint = new TextView(c);
        hint.setTextColor(ContextCompat.getColor(c, R.color.muted));
        hint.setTextSize(13);
        hint.setText(emptyHint == null ? "" : emptyHint);
        hint.setVisibility(View.GONE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = Ui.dp(c, 6);
        view.addView(hint, hp);

        list = new RecyclerView(c);
        list.setLayoutManager(new LinearLayoutManager(c, LinearLayoutManager.HORIZONTAL, false));
        list.setAdapter(adapter);
        list.setClipToPadding(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 8);
        view.addView(list, lp);
    }

    public void setTitle(String t) {
        heading.setText(t);
    }

    public void set(List<Card> cards) {
        adapter.data = cards == null ? new ArrayList<Card>() : cards;
        adapter.notifyDataSetChanged();
        boolean empty = adapter.data.isEmpty();
        if (empty && emptyHint == null) {
            view.setVisibility(View.GONE);
            return;
        }
        view.setVisibility(View.VISIBLE);
        hint.setVisibility(empty ? View.VISIBLE : View.GONE);
        list.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private static final class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        List<Card> data = new ArrayList<>();

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            boolean wide = viewType == 1;
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_card_focus);
            card.setFocusable(true);
            card.setClickable(true);
            card.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    Ui.dp(c, wide ? 230 : 140), ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(Ui.dp(c, 10));
            card.setLayoutParams(lp);

            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
            card.addView(img, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 96)));
            if (wide) img.setVisibility(View.GONE);

            TextView badge = new TextView(c);
            badge.setTextColor(0xFFFFFFFF);
            badge.setTextSize(11);
            badge.setBackgroundColor(0xFFD32F2F);
            badge.setPadding(Ui.dp(c, 6), Ui.dp(c, 2), Ui.dp(c, 6), Ui.dp(c, 2));
            badge.setVisibility(View.GONE);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bp.topMargin = Ui.dp(c, 4);
            card.addView(badge, bp);

            TextView title = new TextView(c);
            title.setTextColor(ContextCompat.getColor(c, R.color.text));
            title.setTextSize(13);
            title.setMinLines(2);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            title.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            title.setGravity(Gravity.START);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 6);
            card.addView(title, tp);

            TextView sub = new TextView(c);
            sub.setTextColor(ContextCompat.getColor(c, R.color.muted));
            sub.setTextSize(11);
            sub.setMaxLines(1);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            sub.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            card.addView(sub);

            return new VH(card, img, badge, title, sub);
        }

        @Override
        public int getItemViewType(int position) {
            return data.get(position).wide ? 1 : 0;
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Card card = data.get(position);
            h.title.setText(card.title);
            h.sub.setText(card.subtitle);
            h.sub.setVisibility(card.subtitle == null || card.subtitle.isEmpty() ? View.GONE : View.VISIBLE);
            boolean hasBadge = card.badge != null && !card.badge.isEmpty();
            h.badge.setText(card.badge);
            h.badge.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
            if (!card.wide) {
                Context c = h.itemView.getContext();
                if (card.image != null && card.image.startsWith("http")) {
                    Glide.with(c).load(card.image).override(300, 200)
                            .placeholder(card.fallback).error(card.fallback).into(h.img);
                } else {
                    Glide.with(c).clear(h.img);
                    h.img.setImageResource(card.fallback);
                }
            }
            h.itemView.setOnClickListener(v -> {
                if (card.click != null) card.click.run();
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static final class VH extends RecyclerView.ViewHolder {
            final ImageView img;
            final TextView badge, title, sub;

            VH(@NonNull View v, ImageView img, TextView badge, TextView title, TextView sub) {
                super(v);
                this.img = img;
                this.badge = badge;
                this.title = title;
                this.sub = sub;
            }
        }
    }
}
